import React, { useState } from "react";
import axios from "axios";

// const OPENAI_API_KEY =
//   "DEiBOTM8WWZhfnUK1qoccUvXpt79dpoGXglmvT2Z6MPCXGkON3FMJQQJ99BGACHrzpqXJ3w3AAAAACOGgMA2"; // Replace with your actual API key

export default function SpeechToText() {
  const [audioFile, setAudioFile] = useState(null);
  const [transcript, setTranscript] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleFileChange = (e) => {
    setAudioFile(e.target.files[0]);
    setTranscript("");
    setError("");
  };

  const handleTranscribe = async () => {
    if (!audioFile) {
      setError("Please upload an audio file first.");
      return;
    }
    setLoading(true);
    setError("");
    setTranscript("");
    const formData = new FormData();
    formData.append("file", audioFile);

    try {
      const response = await axios.post(
        "http://localhost:5000/api/transcribe", // your backend endpoint
        formData
      );
      setTranscript(response.data.text);
    } catch (err) {
      setError(
        "Transcription failed. " + (err.response?.data?.error || err.message)
      );
    }
    setLoading(false);
  };

  return (
    <div
      style={{
        maxWidth: 400,
        margin: "2rem auto",
        padding: 16,
        border: "1px solid #eee",
        borderRadius: 8,
      }}
    >
      <h2>Voice File to Text</h2>
      <input type="file" accept="audio/*" onChange={handleFileChange} />
      <button
        onClick={handleTranscribe}
        disabled={loading || !audioFile}
        style={{ marginLeft: 8 }}
      >
        {loading ? "Transcribing..." : "Transcribe"}
      </button>
      {error && <div style={{ color: "red", marginTop: 12 }}>{error}</div>}
      {transcript && (
        <div style={{ marginTop: 16 }}>
          <h4>Transcript:</h4>
          <div style={{ padding: 8, borderRadius: 4 }}>{transcript}</div>
        </div>
      )}
    </div>
  );
}
