import React, { useState, useRef } from "react";

export default function AudioRecorder({ onRecordingReady }) {
  const [recording, setRecording] = useState(false);
  const [audioURL, setAudioURL] = useState("");
  const [error, setError] = useState("");
  const mediaRecorderRef = useRef(null);
  const audioChunks = useRef([]);

  const startRecording = async () => {
    setError("");
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioChunks.current = [];
      const mediaRecorder = new window.MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) audioChunks.current.push(event.data);
      };

      mediaRecorder.onstop = () => {
        // Clean up the stream
        stream.getTracks().forEach(track => track.stop());
        // Build the audio Blob and show the controls
        const audioBlob = new Blob(audioChunks.current, { type: "audio/webm" });
        if (audioBlob.size === 0) {
          setError("No audio recorded. Please try again.");
          setAudioURL("");
          return;
        }
        const url = URL.createObjectURL(audioBlob);
        setAudioURL(url);
        if (onRecordingReady) onRecordingReady(audioBlob);
      };

      mediaRecorder.start();
      setRecording(true);
    } catch (err) {
      setError("Could not access microphone. Please allow mic permissions.");
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && recording) {
      mediaRecorderRef.current.stop();
      setRecording(false);
    }
  };

  return (
    <div style={{ margin: 20 }}>
      <button onClick={recording ? stopRecording : startRecording}>
        {recording ? "Stop Recording" : "Start Recording"}
      </button>
      {error && <div style={{ color: "red", marginTop: 10 }}>{error}</div>}
      {audioURL && (
        <div style={{ marginTop: 16 }}>
          <audio src={audioURL} controls />
          <a href={audioURL} download="recording.webm" style={{ marginLeft: 10 }}>
            Download WebM
          </a>
        </div>
      )}
    </div>
  );
}
