import logo from "./logo.svg";
import "./App.css";
import SpeechToText from "./SpeechToText";
import React, { useState, useRef } from "react";

const LANGUAGES = [
  { label: "English (US)", code: "en-US" },
  { label: "Hindi", code: "hi-IN" },
  { label: "Marathi", code: "mr-IN" },
  { label: "Kannada", code: "kn-IN" },
  { label: "French", code: "fr-FR" },
  { label: "German", code: "de-DE" },
];

function AudioRecorder({ onRecordingReady }) {
  const [recording, setRecording] = useState(false);
  const [audioURL, setAudioURL] = useState("");
  const [error, setError] = useState("");
  const mediaRecorderRef = useRef(null);
  const audioChunks = useRef([]);

  const startRecording = async () => {
    setError("");
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioChunks.current = [];
      const mediaRecorder = new window.MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) audioChunks.current.push(event.data);
      };

      mediaRecorder.onstop = () => {
        stream.getTracks().forEach((track) => track.stop());
        const audioBlob = new Blob(audioChunks.current, { type: "audio/webm" });
        if (audioBlob.size === 0) {
          setError("No audio recorded. Please try again.");
          setAudioURL("");
          return;
        }
        const url = URL.createObjectURL(audioBlob);
        setAudioURL(url);
        if (onRecordingReady) onRecordingReady(audioBlob);
      };

      mediaRecorder.start();
      setRecording(true);
    } catch (err) {
      setError("Could not access microphone. Please allow mic permissions.");
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && recording) {
      mediaRecorderRef.current.stop();
      setRecording(false);
    }
  };

  return (
    <div style={styles.card}>
      <h3 style={styles.sectionTitle}>Record Audio & Transcribe</h3>
      <button
        onClick={recording ? stopRecording : startRecording}
        style={{
          ...styles.button,
          background: recording ? "#e74c3c" : "#3498db",
        }}
      >
        {recording ? "Stop Recording" : "Start Recording"}
      </button>
      {error && <div style={styles.error}>{error}</div>}
      {audioURL && (
        <div style={{ marginTop: 16 }}>
          <audio src={audioURL} controls style={{ width: "100%" }} />
          <a
            href={audioURL}
            download="recording.webm"
            style={styles.linkButton}
          >
            Download Audio
          </a>
        </div>
      )}
    </div>
  );
}

function App() {
  const [transcript, setTranscript] = useState("");
  const [loading, setLoading] = useState(false);
  const [language, setLanguage] = useState("en-US");

  const handleRecordingReady = async (audioBlob) => {
    setTranscript("");
    setLoading(true);
    const formData = new FormData();
    formData.append("file", audioBlob, "recording.webm");
    formData.append("language", language);
    try {
      const response = await fetch("http://localhost:5000/api/transcribe", {
        method: "POST",
        body: formData,
      });
      const data = await response.json();
      setTranscript(data.text);
    } catch (err) {
      setTranscript("Transcription failed.");
    }
    setLoading(false);
  };

  return (
    <div
      className="App"
      style={{
        minHeight: "100vh",
        background: "linear-gradient(120deg,#f5f7fa 0%, #c3cfe2 100%)",
      }}
    >
      <header className="App-header" style={{ paddingTop: 32 }}>
        <img src={logo} className="App-logo" alt="logo" style={{ width: 90, marginBottom: 8 }} />
        <h2 style={{ color: "#222", marginBottom: 8 }}>Speech to Text Transcriber</h2>
        <div style={styles.card}>
          <h3 style={styles.sectionTitle}>Select Language</h3>
          <select
            value={language}
            onChange={(e) => setLanguage(e.target.value)}
            style={styles.select}
          >
            {LANGUAGES.map((lang) => (
              <option key={lang.code} value={lang.code}>
                {lang.label}
              </option>
            ))}
          </select>
        </div>
        <AudioRecorder onRecordingReady={handleRecordingReady} />

        <div style={styles.card}>
          <h3 style={styles.sectionTitle}>Transcript</h3>
          {loading && <div style={styles.loading}>Transcribing...</div>}
          {transcript && (
            <div style={styles.transcriptBox}>{transcript}</div>
          )}
        </div>

        <div style={{ marginTop: 40, width: "100%" }}>
          <div style={styles.card}>
            <h3 style={styles.sectionTitle}>Or Upload a Voice File</h3>
            <SpeechToText />
          </div>
        </div>
      </header>
    </div>
  );
}

const styles = {
  card: {
    background: "#fff",
    borderRadius: 18,
    boxShadow: "0 6px 24px rgba(44,62,80,0.08)",
    padding: "24px 32px",
    margin: "18px auto",
    width: "100%",
    maxWidth: 480,
    textAlign: "left",
  },
  sectionTitle: {
    color: "#222",
    fontWeight: "600",
    marginBottom: 12,
    letterSpacing: 0.5,
  },
  button: {
    fontWeight: 600,
    fontSize: 16,
    color: "#fff",
    border: "none",
    outline: "none",
    padding: "12px 32px",
    borderRadius: 22,
    cursor: "pointer",
    marginTop: 8,
    boxShadow: "0 2px 12px rgba(52,152,219,0.09)",
    transition: "background 0.2s",
  },
  linkButton: {
    display: "inline-block",
    marginTop: 10,
    color: "#2980b9",
    textDecoration: "none",
    fontWeight: 500,
    fontSize: 15,
  },
  error: {
    color: "#e74c3c",
    marginTop: 10,
    fontWeight: 600,
  },
  select: {
    width: "100%",
    padding: "10px",
    fontSize: 15,
    borderRadius: 12,
    border: "1px solid #d0d0d0",
    marginBottom: 4,
  },
  loading: {
    color: "#888",
    fontWeight: 600,
    padding: 10,
  },
  transcriptBox: {
    background: "#f6f8fa",
    color: "#26324b",
    borderRadius: 8,
    padding: 16,
    fontSize: 16,
    fontFamily: "inherit",
    marginTop: 8,
    marginBottom: 8,
    lineHeight: 1.5,
    minHeight: 30,
  },
};

export default App;
