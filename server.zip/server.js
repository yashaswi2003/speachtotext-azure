const express = require("express");
const multer = require("multer");
const axios = require("axios");
const fs = require("fs");
const cors = require("cors");
// const ffmpeg = require("fluent-ffmpeg");
const path = require("path");

const app = express();
const upload = multer({ dest: "uploads/" });
app.use(cors());

const ffmpegPath = require('ffmpeg-static');
const ffmpeg = require('fluent-ffmpeg');
ffmpeg.setFfmpegPath(ffmpegPath);

const SPEECH_KEY =""; // Replace with your actual key
const REGION = "swedencentral"; // Replace with your Azure region

app.post("/api/transcribe", upload.single("file"), (req, res) => {
  const inputPath = req.file.path;
  const outputPath = `${inputPath}.wav`;
  const language = req.body.language || 'en-US'; // fallback to English (US)


  // Convert to WAV using ffmpeg
  ffmpeg(inputPath)
    .toFormat("wav")
    .on("end", async () => {
      try {
        const audioBuffer = fs.readFileSync(outputPath);


        // Send to Azure
        const azureRes = await axios.post(
          `https://${REGION}.stt.speech.microsoft.com/speech/recognition/conversation/cognitiveservices/v1?language=${language}`,
          audioBuffer,
          {
            headers: {
              "Ocp-Apim-Subscription-Key": SPEECH_KEY,
              "Content-Type": "audio/wav",
              Accept: "application/json",
            },
          }
        );

        // Clean up temp files
        fs.unlinkSync(inputPath);
        fs.unlinkSync(outputPath);

        console.log("Azure response:", azureRes.data);

        res.json({
          text: azureRes.data.DisplayText || "No transcription found.",
        });
      } catch (error) {
        fs.unlinkSync(inputPath);
        if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath);
        res.status(500).json({ error: error.message });
      }
    })
    .on("error", (err) => {
      fs.unlinkSync(inputPath);
      if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath);
      res.status(500).json({ error: "Conversion failed: " + err.message });
    })
    .save(outputPath);
});

const PORT = 5000;
app.listen(PORT, () => console.log(`Backend listening on port ${PORT}`));
